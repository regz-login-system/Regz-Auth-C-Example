﻿using System;
using System.Windows.Forms;

namespace Regz_Auth_C__Example
{
    public partial class MainForm : Form
    {
        private RegzAuth auth;

        public MainForm()
        {
            InitializeComponent();
            auth = new RegzAuth();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            var username = txtUsername.Text;
            var password = txtPassword.Text;
            bool versionOk = await auth.CheckVersion();
            bool success = await auth.Login(username, password);

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                return;
            }
            
            if (!versionOk)
            {
                return;
            }

            if (!success)
            {
                return;
            }

            if (auth.license.banned)
            {
                return;
            }

            if (!auth.license.admin_approval)
            {
                return;
            }

            if (auth.license.expiredate != null)
            {
                DateTime? expireDate = auth.license.expiredate;

                string expireDateString = expireDate?.ToString("yyyy-MM-dd") ?? "No Expiry Date";

                if (expireDate < DateTime.UtcNow)
                {
                    return;
                }
            }

            this.Hide();
            var form2 = new Form2();
            form2.ShowDialog();
            this.Close();
        }



        private async void button2_Click(object sender, EventArgs e)
        {
            var username = txtUsername.Text;
            var password = txtPassword.Text;
            var licenseKey = txtLicenseKey.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(licenseKey))
            {
                MessageBox.Show("Please fill all fields.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool success = await auth.Register(username, password, licenseKey);
            if (success)
            {
            }
            else
            {
            }
        }

        public void ShowMessage(string message)
        {
            MessageBox.Show(message);
        }

        private void OnClose(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
