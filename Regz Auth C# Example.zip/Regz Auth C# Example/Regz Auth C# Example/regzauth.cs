﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Management;
using System.Security.Cryptography;
using System.Linq;
using System.Windows.Forms;

namespace Regz_Auth_C__Example
{
    public class RegzAuth
    {
        private readonly string _supabaseUrl = "";
        private readonly string _supabaseKey = "";
        private readonly string _appVersion = "1.0";
        private readonly HttpClient _httpClient;
        internal License license;

        public RegzAuth()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _supabaseKey);
            _httpClient.DefaultRequestHeaders.Add("apikey", _supabaseKey);
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
        }

        public async Task<bool> CheckVersion()
        {
            var url = $"{_supabaseUrl}/rest/v1/app_version?select=version&order=id.desc&limit=1";
            var response = await _httpClient.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                MessageBox.Show("Failed to check version.");
                return false;
            }

            var content = await response.Content.ReadAsStringAsync();
            var versions = JsonSerializer.Deserialize<List<AppVersion>>(content);

            if (versions == null || versions.Count == 0)
                return false;

            if (versions[0].version == _appVersion)
                return true;
            else
            {
                MessageBox.Show($"Update Required! Server version: {versions[0].version}");
                return false;
            }
        }

        private class AppVersion
        {
            public string version { get; set; }
        }

        public string GetHWID()
        {
            try
            {
                var searcher = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BaseBoard");
                foreach (var item in searcher.Get())
                {
                    return ComputeSha256Hash(item["SerialNumber"].ToString());
                }
            }
            catch { }
            return "UnknownHWID";
        }

        private string ComputeSha256Hash(string rawData)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                foreach (var b in bytes)
                    builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }

        public async Task<bool> Login(string username, string password)
        {
            var url = $"{_supabaseUrl}/rest/v1/users?username=eq.{username}&password=eq.{password}&select=*";
            var response = await _httpClient.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                MessageBox.Show("Failed to connect to server.");
                return false;
            }

            var content = await response.Content.ReadAsStringAsync();
            var users = JsonSerializer.Deserialize<List<User>>(content);

            if (users == null || users.Count == 0)
            {
                MessageBox.Show("Invalid username or password.");
                return false;
            }

            var user = users[0];

            license = new License
            {
                banned = user.banned,
                admin_approval = user.admin_approval,
                expiredate = user.expiredate
            };

            if (license.banned)
            {
                MessageBox.Show("Your account is banned.");
                return false;
            }

            if (!license.admin_approval)
            {
                MessageBox.Show("Waiting for admin approval.");
                return false;
            }

            if (license.expiredate != null && license.expiredate < DateTime.UtcNow)
            {
                MessageBox.Show("Your subscription has expired.");
                return false;
            }

            var hwid = GetHWID();
            if (user.hwid != null && user.hwid.Contains(hwid))
            {
                MessageBox.Show("Login successful!");
                return true;
            }
            else
            {
                if (user.hwid == null)
                    user.hwid = new List<string>();

                if (user.hwid.Count < user.max_devices)
                {
                    user.hwid.Add(hwid);
                    await UpdateHWID(user.id, user.hwid);
                    MessageBox.Show("HWID added. Login successful!");
                    return true;
                }
                else
                {
                    MessageBox.Show("HWID limit reached. Contact support.");
                    return false;
                }
            }
        }

        private async Task UpdateHWID(int userId, List<string> hwids)
        {
            var url = $"{_supabaseUrl}/rest/v1/users?id=eq.{userId}";
            var data = new { hwid = hwids };

            var json = JsonSerializer.Serialize(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            await PatchAsync(_httpClient, url, content);
        }

        private static async Task<HttpResponseMessage> PatchAsync(HttpClient client, string requestUri, HttpContent content)
        {
            var method = new HttpMethod("PATCH");
            var request = new HttpRequestMessage(method, requestUri)
            {
                Content = content
            };
            return await client.SendAsync(request);
        }

        public async Task<bool> Register(string username, string password, string licenseKey)
        {
            var licenseUrl = $"{_supabaseUrl}/rest/v1/license_keys?license_key=eq.{licenseKey}&select=*";
            var licenseResponse = await _httpClient.GetAsync(licenseUrl);

            if (!licenseResponse.IsSuccessStatusCode)
            {
                MessageBox.Show("Failed to validate license key.");
                return false;
            }

            var licenseContent = await licenseResponse.Content.ReadAsStringAsync();
            var licenses = JsonSerializer.Deserialize<List<LicenseKey>>(licenseContent);

            if (licenses == null || licenses.Count == 0)
            {
                MessageBox.Show("Invalid or already used license key.");
                return false;
            }

            var license = licenses[0];

            if (license.banned)
            {
                MessageBox.Show("License key is banned.");
                return false;
            }

            if (!license.admin_approval)
            {
                MessageBox.Show("License key awaiting approval.");
                return false;
            }

            if (license.expiredate != null && license.expiredate < DateTime.UtcNow)
            {
                MessageBox.Show("License key expired.");
                return false;
            }

            var hwid = GetHWID();

            var userData = new
            {
                username = username,
                password = password,
                key = licenseKey,
                hwid = new List<string> { hwid },
                subscription = license.subscription,
                expiredate = license.expiredate,
                admin_approval = true,
                max_devices = license.max_devices ?? 1
            };

            var json = JsonSerializer.Serialize(userData);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var userUrl = $"{_supabaseUrl}/rest/v1/users";
            var userResponse = await _httpClient.PostAsync(userUrl, content);

            if (!userResponse.IsSuccessStatusCode)
            {
                MessageBox.Show("Failed to register user.");
                return false;
            }

            await _httpClient.DeleteAsync($"{_supabaseUrl}/rest/v1/license_keys?license_key=eq.{licenseKey}");

            MessageBox.Show("Registration successful!");
            return true;
        }
    }

    public class License
    {
        public bool banned { get; set; }
        public bool admin_approval { get; set; }
        public DateTime? expiredate { get; set; }
    }

    public class User
    {
        public int id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string license_key { get; set; }
        public List<string> hwid { get; set; }
        public int max_devices { get; set; }
        public bool banned { get; set; }
        public bool admin_approval { get; set; }
        public DateTime? expiredate { get; set; }
    }

    public class LicenseKey
    {
        public string license_key { get; set; }
        public bool banned { get; set; }
        public bool admin_approval { get; set; }
        public DateTime? expiredate { get; set; }
        public string subscription { get; set; }
        public int? max_devices { get; set; }
    }
}
