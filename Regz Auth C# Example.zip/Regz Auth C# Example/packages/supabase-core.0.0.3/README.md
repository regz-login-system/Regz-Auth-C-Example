<p align="center">
<img width="300" src=".github/supabase-core.png"/>
</p>
<p align="center">
  <img src="https://github.com/supabase-community/core-csharp/workflows/Build%20And%20Test/badge.svg"/>
  <a href="https://www.nuget.org/packages/supabase-core/">
    <img src="https://img.shields.io/nuget/vpre/supabase-core"/>
  </a>
</p>

This repo contains shared resources for the [supabase-csharp](https://github.com/supabase-community/supabase-csharp) repo and its dependent libraries.

## Package made possible through the efforts of:

Join the ranks! See a problem? Help fix it!

<a href="https://github.com/supabase-community/core-csharp/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=supabase-community/core-csharp" />
</a>

Made with [contrib.rocks](https://contrib.rocks/preview?repo=supabase-community%core-csharp).

## Contributing

We are more than happy to have contributions! Please submit a PR.
